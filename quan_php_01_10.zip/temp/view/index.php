<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
	<?php include_once("header.php"); ?>
    <?php include_once("nav.php"); ?>
    <div class="container">
    <?php include_once("studentinformation.php"); ?>
</div>
    <?php include_once("footer.php"); ?>
</body>

</html>