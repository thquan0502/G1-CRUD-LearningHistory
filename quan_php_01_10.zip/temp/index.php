<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
	<?php include_once("view/header.php"); ?>
    <?php include_once("view/nav.php"); ?>
    <div class="container">
    <?php include_once("view/studentinformation.php"); ?>
</div>
    <?php include_once("view/footer.php"); ?>
</body>

</html>