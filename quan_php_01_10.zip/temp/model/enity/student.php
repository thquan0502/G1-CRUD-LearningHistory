<?php
  /**
   *  
   */
  class Student
  {
    var $id;
  	var $firstName;
    var $lastName;
    var $dateOfBirth;//DOB
    var $placeOfBirth;//POB
  	
  	function display(){
  		echo "Họ tên: ". $firstName." ". $lastName."<br>";
  		echo "Ngày Sinh: #dateOfBirth<br>";
  		echo "Nơi Sinh: #placeOfBirth<br>";

  	}
  };
?>
