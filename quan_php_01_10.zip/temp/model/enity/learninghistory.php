<?php
	/**
	 * 
	 */
	class Learninghistory{
		private $id;
		private $yearFrom;
		private $yearTo;
		private $schoolName;
		private $schoolAddress;
		private $idStudent;
			# code...
		public function __construct($id,$yearFrom,$yearTo,$schoolName,$schoolAddress,$idStudent){
			$this->id = $id;
			$this->yearFrom= $yearFrom;
			$this->yearTo= $yearTo;
			$this->schoolName= $schoolName;
			$this->schoolAddress= $schoolAddress;
			$this->idStudent= $idStudent;
		}
		public static function getList($idStudent){
			$rs =	array();
			for($i=0; $i<5; $i++){
			array_push($rs,new Learninghistory(
				$i,
				2001+ $i,
				2002+ $i,
				"Phan Boi Chau" .$i,
				"Hue",
				$idStudent));
 			}
			return $rs;
		}

		public static function getListFromFile($idStudent){
			$lines = file("../resource/learninghistory.txt", FILE_IGNORE_NEW_LINES);
			$rs = array();
			foreach ($lines as $key => $value) {
				$arr = explode("#", $value);
				if($arr[5] == $idStudent)
				array_push($rs, new Learninghistory(
					$arr[0],
					$arr[1],
					$arr[2],
					$arr[3],
					$arr[4],
					$arr[5]
				));
				# code...
			}
			return $rs;			
		}

		public static function saveToFile($filePath, $stt, $tuNam, $denNam, $lop, $noiHoc){

			$myfile = fopen($filePath, "a") or die("Unable to open file!");
			// file_put_contents('logs.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);

			// $txt = "John Doe\n";
			// fwrite($myfile, $txt);
			// $txt = "Jane Doe\n";
			// fwrite($myfile, $txt);
			// echo $noiHoc;
			$string = "" . $stt . "|" . $tuNam . "|" . $denNam . "|" . $lop . "|" . $noiHoc . "\n";

			fwrite($myfile, $string);

			fclose($myfile);
		}

	}
?>